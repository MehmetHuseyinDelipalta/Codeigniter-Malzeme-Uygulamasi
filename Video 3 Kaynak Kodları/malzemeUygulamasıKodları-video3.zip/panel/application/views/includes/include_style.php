<link href="<?php echo base_url("assets/assets/bootstrap/css/bootstrap.min.css"); ?>" rel=" stylesheet"/>
<link href="<?php echo base_url("assets/assets/bootstrap/css/bootstrap-responsive.min.css"); ?>" rel="stylesheet"/>
<link href="<?php echo base_url("assets/assets/bootstrap/css/bootstrap-fileupload.css"); ?>" rel="stylesheet"/>
<link href="<?php echo base_url("assets/assets/font-awesome/css/font-awesome.css"); ?>" rel="stylesheet"/>
<link href="<?php echo base_url("assets/css/style.css"); ?>" rel="stylesheet"/>
<link href="<?php echo base_url("assets/css/style-responsive.css"); ?>" rel="stylesheet"/>
<link href="<?php echo base_url("assets/css/style-default.css"); ?>" rel="stylesheet" id="style_color"/>
<link href="<?php echo base_url("assets/css/custom.css"); ?>" rel="stylesheet"/>
<!-- notifIt css dosyasını çektiği yer -->
<link href="<?php echo base_url("assets/css//third_party/notifIt.css"); ?>" rel="stylesheet"/>