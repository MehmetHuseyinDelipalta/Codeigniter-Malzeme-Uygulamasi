<!-- BEGIN JAVASCRIPTS -->
<!-- Load javascripts at bottom, this will reduce page load time -->
<script src="<?php echo base_url("assets"); ?>/js/jquery-1.8.3.min.js"></script>
<script src="<?php echo base_url("assets"); ?>/js/jquery.nicescroll.js" type="text/javascript"></script>
<script src="<?php echo base_url("assets"); ?>/assets/bootstrap/js/bootstrap.min.js"></script>
<script src="<?php echo base_url("assets"); ?>/js/jquery.scrollTo.min.js"></script>

<!-- ie8 fixes -->
<!--[if lt IE 9]> -->
<script src="<?php echo base_url("assets"); ?>/js/excanvas.js"></script>
<script src="<?php echo base_url("assets"); ?>/js/respond.js"></script>
<![endif]-->

<!--common script for all pages-->
<script src="<?php echo base_url("assets"); ?>/js/common-scripts.js"></script>
<script src="<?php echo base_url("assets"); ?>/js/custom.js"></script>

<!-- notifIt Scriptini çektiği yer -->
<script src="<?php echo base_url("assets"); ?>/js//third_party/notifIt.js"></script>

