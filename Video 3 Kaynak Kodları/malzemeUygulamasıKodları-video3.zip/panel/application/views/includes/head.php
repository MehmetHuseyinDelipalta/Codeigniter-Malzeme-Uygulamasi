<meta charset="utf-8" />
<title>Blank</title>
<meta content="width=device-width, initial-scale=1.0" name="viewport" />
<meta content="" name="description" />
<meta content="" name="author" />
<?php $this->load->view("includes/include_style"); ?>